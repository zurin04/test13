#!/bin/bash

# Quick deployment health check script

echo "================================================="
echo "Personal Finance Tracker - Deployment Health Check"
echo "================================================="

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

check_pass() { echo -e "${GREEN}✓${NC} $1"; }
check_fail() { echo -e "${RED}✗${NC} $1"; }
check_warn() { echo -e "${YELLOW}⚠${NC} $1"; }

# Check PM2 status
echo "Checking PM2 application status..."
if pm2 list | grep -q "personal-finance-tracker.*online"; then
    check_pass "Application is running in PM2"
else
    check_fail "Application not running in PM2"
    echo "Run: pm2 start ecosystem.config.cjs"
fi

# Check database connection
echo "Checking database connection..."
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
    if PGPASSWORD="$PGPASSWORD" psql -h localhost -U finance_user -d personal_finance_db -c "SELECT 1;" >/dev/null 2>&1; then
        check_pass "Database connection successful"
    else
        check_fail "Database connection failed"
    fi
else
    check_warn ".env file not found"
fi

# Check application response
echo "Checking application response..."
if curl -f -s http://localhost:5000/api/health > /dev/null; then
    check_pass "Application responding on port 5000"
else
    check_fail "Application not responding on port 5000"
fi

# Check Nginx status
echo "Checking Nginx..."
if systemctl is-active --quiet nginx; then
    check_pass "Nginx service is running"
else
    check_fail "Nginx service not running"
fi

# Check if port 80 is responding
echo "Checking web server response..."
if curl -f -s http://localhost > /dev/null; then
    check_pass "Web server responding on port 80"
else
    check_fail "Web server not responding on port 80"
fi

# Check recent errors
echo "Checking recent application logs..."
if [ -f "/var/log/personal-finance-tracker/error.log" ]; then
    ERROR_COUNT=$(tail -100 /var/log/personal-finance-tracker/error.log | grep -i error | wc -l)
    if [ $ERROR_COUNT -eq 0 ]; then
        check_pass "No recent errors in application logs"
    else
        check_warn "$ERROR_COUNT errors found in recent logs"
    fi
else
    check_warn "Application log file not found"
fi

# Check disk space
echo "Checking disk space..."
DISK_USAGE=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
if [ $DISK_USAGE -lt 80 ]; then
    check_pass "Disk usage: ${DISK_USAGE}%"
else
    check_warn "High disk usage: ${DISK_USAGE}%"
fi

# Check memory usage
echo "Checking memory usage..."
MEMORY_USAGE=$(free | awk 'NR==2{printf "%.0f", $3*100/$2}')
if [ $MEMORY_USAGE -lt 80 ]; then
    check_pass "Memory usage: ${MEMORY_USAGE}%"
else
    check_warn "High memory usage: ${MEMORY_USAGE}%"
fi

echo ""
echo "================================================="
echo "Health check completed!"
echo ""
echo "Quick commands:"
echo "  ./manage.sh status   - Check detailed status"
echo "  ./manage.sh logs     - View application logs"
echo "  ./manage.sh restart  - Restart application"
echo "================================================="