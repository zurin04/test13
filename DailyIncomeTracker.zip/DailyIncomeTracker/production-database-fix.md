# Production Database Connection Fix

## Problem
The DATABASE_URL in your production environment contains special characters (`/` and `+`) in the password that are not properly URL-encoded, causing connection failures.

## Current Error
```
TypeError: Invalid URL
input: 'postgresql://finance_user:uvbI6/+SGCc8/lv+GeUmQecOCq1tk4u9YpnzdCInf3o=@localhost:5432/personal_finance_db'
```

## Solution Options

### Option 1: Fix the DATABASE_URL (Recommended)
URL-encode the password in your DATABASE_URL:

**Current (broken):**
```
postgresql://finance_user:uvbI6/+SGCc8/lv+GeUmQecOCq1tk4u9YpnzdCInf3o=@localhost:5432/personal_finance_db
```

**Fixed (URL-encoded password):**
```
postgresql://finance_user:uvbI6%2F%2BSGCc8%2Flv%2BGeUmQecOCq1tk4u9YpnzdCInf3o%3D@localhost:5432/personal_finance_db
```

### Option 2: Use Individual Environment Variables
Instead of DATABASE_URL, set these individual variables:

```bash
export PGHOST=localhost
export PGPORT=5432
export PGUSER=finance_user
export PGPASSWORD='uvbI6/+SGCc8/lv+GeUmQecOCq1tk4u9YpnzdCInf3o='
export PGDATABASE=personal_finance_db
```

## Implementation Steps

### For Option 1 (URL-encoded DATABASE_URL):
1. Update your environment variables:
   ```bash
   export DATABASE_URL="postgresql://finance_user:uvbI6%2F%2BSGCc8%2Flv%2BGeUmQecOCq1tk4u9YpnzdCInf3o%3D@localhost:5432/personal_finance_db"
   ```

2. Restart your application:
   ```bash
   pm2 restart personal-finance-tracker
   ```

### For Option 2 (Individual variables):
1. Remove or comment out DATABASE_URL:
   ```bash
   # export DATABASE_URL="..."
   ```

2. Set individual variables:
   ```bash
   export PGHOST=localhost
   export PGPORT=5432
   export PGUSER=finance_user
   export PGPASSWORD='uvbI6/+SGCc8/lv+GeUmQecOCq1tk4u9YpnzdCInf3o='
   export PGDATABASE=personal_finance_db
   ```

3. Restart your application:
   ```bash
   pm2 restart personal-finance-tracker
   ```

## URL Encoding Reference
- `/` becomes `%2F`
- `+` becomes `%2B`
- `=` becomes `%3D`

## Testing the Fix
After implementing either option, test the database connection:

```bash
# Test database push
npm run db:push

# Check application logs
pm2 logs personal-finance-tracker
```

## Updated Application Support
The application now supports both connection methods:
- If DATABASE_URL is set, it will use the connection string
- If DATABASE_URL is not set, it will use individual PGHOST, PGPORT, PGUSER, PGPASSWORD, PGDATABASE variables

This provides flexibility for different deployment environments.