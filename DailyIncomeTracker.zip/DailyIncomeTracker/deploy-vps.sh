#!/bin/bash

# Personal Finance Tracker - Production VPS Deployment
# One-click deployment script for Ubuntu VPS

set -e

echo "================================================="
echo "Personal Finance Tracker - VPS Deployment"
echo "================================================="

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check prerequisites
[[ $EUID -eq 0 ]] && { print_error "Do not run as root. Use a regular user with sudo privileges."; exit 1; }
command -v sudo >/dev/null || { print_error "sudo is required but not installed."; exit 1; }

# Install system dependencies
print_status "Installing system dependencies..."
sudo apt update -y && sudo apt install -y \
    curl wget gnupg postgresql postgresql-contrib nginx \
    certbot python3-certbot-nginx python3 build-essential \
    git

# Install Node.js 20
if ! command -v node &>/dev/null; then
    print_status "Installing Node.js 20..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
fi

# Install PM2 globally
sudo npm install -g pm2 tsx 2>/dev/null || print_warning "PM2/TSX already installed"

# Start services
sudo systemctl enable --now postgresql nginx

# Setup application directory
APP_DIR="/var/www/personal-finance-tracker"
print_status "Setting up application directory..."
sudo mkdir -p $APP_DIR && sudo chown $USER:$USER $APP_DIR

# Copy application files
print_status "Copying application files..."
cp -r . $APP_DIR/ && cd $APP_DIR

# Generate secure credentials
DB_PASSWORD=$(openssl rand -base64 32)
SESSION_SECRET=$(openssl rand -hex 32)

# Create database and user
print_status "Setting up PostgreSQL database..."
sudo -u postgres psql << EOF
DROP DATABASE IF EXISTS personal_finance_db;
DROP USER IF EXISTS finance_user;
CREATE USER finance_user WITH PASSWORD '$DB_PASSWORD' SUPERUSER;
CREATE DATABASE personal_finance_db OWNER finance_user;
GRANT ALL PRIVILEGES ON DATABASE personal_finance_db TO finance_user;
\q
EOF

# Create environment file
print_status "Creating environment configuration..."
cat > .env << ENV
DATABASE_URL=postgresql://finance_user:$DB_PASSWORD@localhost:5432/personal_finance_db
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000
PGHOST=localhost
PGPORT=5432
PGUSER=finance_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=personal_finance_db
ENV

# Install dependencies
print_status "Installing dependencies..."
npm install

# Setup database schema
print_status "Setting up database schema..."

# URL encode the password to handle special characters
if command -v python3 >/dev/null 2>&1; then
    DB_PASSWORD_ENCODED=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$DB_PASSWORD', safe=''))")
else
    print_warning "Python3 not available, using password as-is"
    DB_PASSWORD_ENCODED="$DB_PASSWORD"
fi

export DATABASE_URL="postgresql://finance_user:$DB_PASSWORD_ENCODED@localhost:5432/personal_finance_db"
export SESSION_SECRET
export NODE_ENV=production

# Test database connection
print_status "Testing database connection..."
if ! PGPASSWORD="$DB_PASSWORD" psql -h localhost -U finance_user -d personal_finance_db -c "SELECT 1;" >/dev/null 2>&1; then
    print_error "Database connection failed. Check PostgreSQL setup."
    exit 1
fi

print_status "Pushing database schema..."
if ! npm run db:push 2>&1; then
    print_warning "Schema push failed, trying with raw password..."
    export DATABASE_URL="postgresql://finance_user:$DB_PASSWORD@localhost:5432/personal_finance_db"
    if ! npm run db:push 2>&1; then
        print_error "Database schema push failed."
        exit 1
    fi
fi

# Update .env with working DATABASE_URL
print_status "Updating environment configuration..."
cat > .env << ENV
DATABASE_URL=$DATABASE_URL
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000
PGHOST=localhost
PGPORT=5432
PGUSER=finance_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=personal_finance_db
ENV

# Build application
print_status "Building application..."
export NODE_OPTIONS="--max-old-space-size=4096"
timeout 600 npm run build || {
    print_warning "Build timed out, trying with less memory..."
    export NODE_OPTIONS="--max-old-space-size=2048"
    timeout 300 npm run build || {
        print_error "Build failed. Check available memory."
        exit 1
    }
}

# Create PM2 ecosystem configuration
print_status "Creating PM2 configuration..."
cat > ecosystem.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'personal-finance-tracker',
    script: './dist/index.js',
    instances: 1,
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    error_file: '/var/log/personal-finance-tracker/error.log',
    out_file: '/var/log/personal-finance-tracker/out.log',
    log_file: '/var/log/personal-finance-tracker/combined.log',
    time: true,
    max_memory_restart: '1G',
    node_args: '--max-old-space-size=1024'
  }]
};
EOF

# Setup logs directory
sudo mkdir -p /var/log/personal-finance-tracker
sudo chown $USER:$USER /var/log/personal-finance-tracker

# Configure Nginx
print_status "Configuring Nginx..."
sudo tee /etc/nginx/sites-available/personal-finance-tracker > /dev/null << 'EOF'
server {
    listen 80;
    server_name _;
    client_max_body_size 50M;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_read_timeout 86400;
    }
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
    add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' data:; connect-src 'self' ws: wss:;";
}
EOF

sudo ln -sf /etc/nginx/sites-available/personal-finance-tracker /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl reload nginx

# Start application with PM2
print_status "Starting application..."
pm2 delete all 2>/dev/null || true
pm2 start ecosystem.config.cjs
pm2 save

# Setup PM2 startup
print_status "Configuring PM2 auto-startup..."
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME

# Verify application is running
print_status "Verifying application startup..."
sleep 5
if pm2 list | grep -q "personal-finance-tracker.*online"; then
    print_status "Application started successfully!"
else
    print_error "Application failed to start. Check logs with: pm2 logs personal-finance-tracker"
    exit 1
fi

# Setup firewall
print_status "Configuring firewall..."
sudo ufw --force enable
sudo ufw allow 22,80,443/tcp

# Create management script
print_status "Creating management script..."
cat > manage.sh << 'SCRIPT'
#!/bin/bash

# Load environment variables
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

BACKUP_DIR="/var/backups/personal-finance-tracker"
APP_DIR="/var/www/personal-finance-tracker"

backup_database() {
    mkdir -p $BACKUP_DIR
    BACKUP_FILE="$BACKUP_DIR/backup_$(date +%Y%m%d_%H%M%S).sql"
    echo "Creating database backup..."
    
    if [ -z "$PGPASSWORD" ]; then
        PGPASSWORD=$(echo "$DATABASE_URL" | sed -n 's/.*:\/\/[^:]*:\([^@]*\)@.*/\1/p')
    fi
    
    if PGPASSWORD="$PGPASSWORD" pg_dump -h localhost -U finance_user personal_finance_db > $BACKUP_FILE; then
        echo "✓ Backup saved to: $BACKUP_FILE"
        ls -t $BACKUP_DIR/backup_*.sql | tail -n +8 | xargs -r rm
        echo "✓ Old backups cleaned up"
    else
        echo "✗ Backup failed!"
        exit 1
    fi
}

restore_database() {
    local backup_file=$2
    if [ -z "$backup_file" ]; then
        echo "Available backups:"
        ls -la $BACKUP_DIR/backup_*.sql 2>/dev/null || echo "No backups found"
        echo "Usage: $0 restore /path/to/backup.sql"
        exit 1
    fi
    
    echo "⚠️  WARNING: This will replace all current data!"
    echo "Press Enter to continue or Ctrl+C to cancel..."
    read
    
    pm2 stop personal-finance-tracker
    
    if [ -z "$PGPASSWORD" ]; then
        PGPASSWORD=$(echo "$DATABASE_URL" | sed -n 's/.*:\/\/[^:]*:\([^@]*\)@.*/\1/p')
    fi
    
    if PGPASSWORD="$PGPASSWORD" psql -h localhost -U finance_user -d personal_finance_db -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;" && \
       PGPASSWORD="$PGPASSWORD" psql -h localhost -U finance_user personal_finance_db < $backup_file; then
        echo "✓ Database restored successfully"
        pm2 start personal-finance-tracker
    else
        echo "✗ Restore failed!"
        pm2 start personal-finance-tracker
        exit 1
    fi
}

safe_update() {
    echo "Starting safe update process..."
    
    backup_database
    
    pm2 stop personal-finance-tracker
    
    if git pull && npm install && npm run db:push && npm run build; then
        echo "✓ Update completed successfully"
        pm2 start personal-finance-tracker
    else
        echo "✗ Update failed!"
        pm2 start personal-finance-tracker
        exit 1
    fi
}

ssl_setup() {
    local domain=$2
    if [ -z "$domain" ]; then
        echo "Usage: $0 ssl yourdomain.com"
        exit 1
    fi
    
    echo "Setting up SSL for domain: $domain"
    
    # Update Nginx config with domain
    sudo sed -i "s/server_name _;/server_name $domain;/" /etc/nginx/sites-available/personal-finance-tracker
    sudo nginx -t && sudo systemctl reload nginx
    
    # Get SSL certificate
    sudo certbot --nginx -d $domain --non-interactive --agree-tos --email admin@$domain
    
    echo "✓ SSL setup completed for $domain"
}

case $1 in
    backup)
        backup_database
        ;;
    restore)
        restore_database $@
        ;;
    update)
        safe_update
        ;;
    ssl)
        ssl_setup $@
        ;;
    logs)
        pm2 logs personal-finance-tracker
        ;;
    status)
        pm2 status
        ;;
    restart)
        pm2 restart personal-finance-tracker
        ;;
    *)
        echo "Personal Finance Tracker Management"
        echo "Usage: $0 {backup|restore|update|ssl|logs|status|restart}"
        echo ""
        echo "Commands:"
        echo "  backup          - Create database backup"
        echo "  restore <file>  - Restore database from backup"
        echo "  update          - Safe update application"
        echo "  ssl <domain>    - Setup SSL certificate"
        echo "  logs            - View application logs"
        echo "  status          - Check application status"
        echo "  restart         - Restart application"
        ;;
esac
SCRIPT

chmod +x manage.sh

# Create verification script
print_status "Creating verification script..."
cat > verify-deployment.sh << 'SCRIPT'
#!/bin/bash

echo "Verifying Personal Finance Tracker deployment..."

# Check if application is running
if pm2 list | grep -q "personal-finance-tracker.*online"; then
    echo "✓ Application is running"
else
    echo "✗ Application is not running"
    exit 1
fi

# Check database connection
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

if PGPASSWORD="$PGPASSWORD" psql -h localhost -U finance_user -d personal_finance_db -c "SELECT 1;" >/dev/null 2>&1; then
    echo "✓ Database connection successful"
else
    echo "✗ Database connection failed"
    exit 1
fi

# Check web server response
if curl -f -s http://localhost:5000 > /dev/null; then
    echo "✓ Web server responding"
else
    echo "✗ Web server not responding"
    exit 1
fi

# Check Nginx configuration
if sudo nginx -t 2>/dev/null; then
    echo "✓ Nginx configuration valid"
else
    echo "✗ Nginx configuration invalid"
    exit 1
fi

echo "✓ All checks passed - deployment verified!"
SCRIPT

chmod +x verify-deployment.sh

# Run verification
print_status "Running deployment verification..."
if ./verify-deployment.sh; then
    print_status "Deployment verification successful!"
else
    print_error "Deployment verification failed!"
    exit 1
fi

# Display final information
echo ""
echo "================================================="
echo "🎉 Personal Finance Tracker deployed successfully!"
echo "================================================="
echo ""
echo "Application URL: http://$(curl -s ifconfig.me 2>/dev/null || echo 'YOUR_SERVER_IP')"
echo "Database: PostgreSQL (personal_finance_db)"
echo "Web Server: Nginx"
echo "Process Manager: PM2"
echo ""
echo "Management Commands:"
echo "  ./manage.sh backup          - Create database backup"
echo "  ./manage.sh restore <file>  - Restore from backup"
echo "  ./manage.sh update          - Safe update application"
echo "  ./manage.sh ssl <domain>    - Setup SSL certificate"
echo "  ./manage.sh logs            - View logs"
echo "  ./manage.sh status          - Check status"
echo "  ./manage.sh restart         - Restart application"
echo ""
echo "Environment file: .env"
echo "Application logs: /var/log/personal-finance-tracker/"
echo ""
echo "To setup SSL certificate:"
echo "  ./manage.sh ssl yourdomain.com"
echo ""
echo "Database credentials saved in .env file"
echo "Keep this file secure and create backups regularly!"
echo ""
echo "🚀 Your Personal Finance Tracker is now live!"