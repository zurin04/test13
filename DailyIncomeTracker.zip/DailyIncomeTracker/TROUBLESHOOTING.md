# Personal Finance Tracker - Troubleshooting Guide

## Common Deployment Issues

### Application Not Starting

**Symptoms:**
- PM2 shows application as "stopped" or "errored"
- Logs show startup errors

**Quick Fixes:**
```bash
# Check application status
./manage.sh status

# View detailed logs
./manage.sh logs

# Restart application
./manage.sh restart

# Check if database is running
sudo systemctl status postgresql

# Test database connection
./check-deployment.sh
```

**Common Causes:**
1. **Database connection failure**
   ```bash
   # Check if PostgreSQL is running
   sudo systemctl start postgresql
   
   # Verify database exists
   sudo -u postgres psql -c "\l" | grep personal_finance_db
   ```

2. **Port already in use**
   ```bash
   # Check what's using port 5000
   sudo netstat -tlnp | grep :5000
   
   # Kill process if needed
   sudo kill -9 <PID>
   ```

3. **Environment variables missing**
   ```bash
   # Check .env file exists and has correct values
   cat .env
   
   # Regenerate if needed
   ./deploy-vps.sh
   ```

### Web Server Not Responding

**Symptoms:**
- Cannot access application via browser
- Nginx errors

**Quick Fixes:**
```bash
# Check Nginx status
sudo systemctl status nginx

# Test Nginx configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx

# Check if port 80 is accessible
curl -I http://localhost
```

**Common Causes:**
1. **Nginx configuration errors**
   ```bash
   # View Nginx error logs
   sudo tail -f /var/log/nginx/error.log
   
   # Reload configuration
   sudo systemctl reload nginx
   ```

2. **Firewall blocking connections**
   ```bash
   # Check firewall status
   sudo ufw status
   
   # Allow HTTP/HTTPS if needed
   sudo ufw allow 80,443/tcp
   ```

### Database Issues

**Symptoms:**
- "Database connection failed" errors
- 500 errors on API calls

**Quick Fixes:**
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Restart PostgreSQL
sudo systemctl restart postgresql

# Test connection manually
PGPASSWORD="your_password" psql -h localhost -U finance_user -d personal_finance_db -c "SELECT 1;"

# Check database schema
npm run db:push
```

**Common Causes:**
1. **PostgreSQL not running**
   ```bash
   sudo systemctl enable postgresql
   sudo systemctl start postgresql
   ```

2. **Wrong credentials**
   ```bash
   # Check .env file for correct DATABASE_URL
   grep DATABASE_URL .env
   
   # Reset database user password if needed
   sudo -u postgres psql -c "ALTER USER finance_user PASSWORD 'new_password';"
   ```

### SSL Certificate Issues

**Symptoms:**
- HTTPS not working
- Certificate warnings

**Quick Fixes:**
```bash
# Check certificate status
sudo certbot certificates

# Renew certificates
sudo certbot renew

# Setup SSL for your domain
./manage.sh ssl yourdomain.com
```

### Performance Issues

**Symptoms:**
- Slow application response
- High memory usage
- Timeouts

**Quick Fixes:**
```bash
# Check system resources
htop

# Check application memory usage
pm2 monit

# Restart application to free memory
./manage.sh restart

# Check disk space
df -h
```

**Optimizations:**
1. **Reduce memory usage**
   ```bash
   # Edit PM2 configuration
   nano ecosystem.config.cjs
   
   # Reduce max_memory_restart to 512M for small VPS
   # Reduce node_args max-old-space-size
   ```

2. **Enable gzip compression**
   ```bash
   # Already configured in Nginx, verify:
   curl -H "Accept-Encoding: gzip" -I http://yourdomain.com
   ```

## Diagnostic Commands

### Quick Health Check
```bash
./check-deployment.sh
```

### Detailed System Check
```bash
# Application status
pm2 list
pm2 info personal-finance-tracker

# System resources
free -h
df -h
uptime

# Network status
sudo netstat -tlnp | grep -E ":(80|443|5000|5432)"

# Service status
sudo systemctl status nginx postgresql

# Recent logs
journalctl -u nginx -n 20
tail -f /var/log/personal-finance-tracker/*.log
```

### Database Diagnostics
```bash
# Check database size
sudo -u postgres psql -c "SELECT pg_database.datname, pg_size_pretty(pg_database_size(pg_database.datname)) AS size FROM pg_database;"

# Check active connections
sudo -u postgres psql -c "SELECT * FROM pg_stat_activity WHERE datname = 'personal_finance_db';"

# Check table sizes
psql "$DATABASE_URL" -c "SELECT tablename, pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) AS size FROM pg_tables WHERE schemaname = 'public';"
```

## Emergency Recovery

### Application Crashed
```bash
# Stop all PM2 processes
pm2 delete all

# Start fresh
pm2 start ecosystem.config.cjs

# If still failing, rebuild
npm run build
pm2 restart all
```

### Database Corrupted
```bash
# Restore from latest backup
./manage.sh restore /var/backups/personal-finance-tracker/backup_YYYYMMDD_HHMMSS.sql

# If no backup, recreate database
sudo -u postgres psql -c "DROP DATABASE personal_finance_db;"
sudo -u postgres psql -c "CREATE DATABASE personal_finance_db OWNER finance_user;"
npm run db:push
```

### Complete System Recovery
```bash
# Stop all services
pm2 delete all
sudo systemctl stop nginx

# Redeploy from scratch
./deploy-vps.sh

# Or restore from backup and redeploy
./manage.sh restore /path/to/backup.sql
npm run build
pm2 start ecosystem.config.cjs
sudo systemctl start nginx
```

## Monitoring and Maintenance

### Regular Maintenance Tasks
```bash
# Weekly: Create backup
./manage.sh backup

# Monthly: Update system packages
sudo apt update && sudo apt upgrade

# Monthly: Clean old logs
sudo journalctl --vacuum-time=30d

# Quarterly: Update application
./manage.sh update
```

### Setting Up Monitoring
```bash
# Install htop for system monitoring
sudo apt install htop

# Setup log rotation
sudo nano /etc/logrotate.d/personal-finance-tracker
```

Add to logrotate config:
```
/var/log/personal-finance-tracker/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 ubuntu ubuntu
    postrotate
        pm2 reload personal-finance-tracker
    endscript
}
```

### Automated Health Checks
Add to crontab (`crontab -e`):
```bash
# Health check every 5 minutes
*/5 * * * * cd /var/www/personal-finance-tracker && ./check-deployment.sh > /dev/null

# Daily backup at 2 AM
0 2 * * * cd /var/www/personal-finance-tracker && ./manage.sh backup

# Weekly log cleanup
0 3 * * 0 find /var/log/personal-finance-tracker -name "*.log" -mtime +7 -delete
```

## Getting Help

### Log Locations
- **Application logs**: `/var/log/personal-finance-tracker/`
- **Nginx logs**: `/var/log/nginx/`
- **PostgreSQL logs**: `/var/log/postgresql/`
- **System logs**: `journalctl -u <service-name>`

### Useful Commands for Support
```bash
# System information
uname -a
lsb_release -a
node --version
pm2 --version

# Application status
pm2 list
./manage.sh status
./check-deployment.sh

# Recent errors
grep -i error /var/log/personal-finance-tracker/*.log | tail -20
sudo tail -20 /var/log/nginx/error.log
```

### Contact Information
When seeking help, include:
1. Output of `./check-deployment.sh`
2. Recent application logs
3. System information
4. Steps that led to the issue
5. Any error messages