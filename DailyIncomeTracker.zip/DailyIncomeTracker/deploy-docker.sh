#!/bin/bash

# Personal Finance Tracker - Docker Deployment Script

set -e

echo "================================================="
echo "Personal Finance Tracker - Docker Deployment"
echo "================================================="

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    print_error "Docker is not installed. Please install Docker first."
    exit 1
fi

# Check if Docker Compose is installed
if ! command -v docker-compose &> /dev/null; then
    print_error "Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi

# Generate environment variables
print_status "Generating environment variables..."
DB_PASSWORD=$(openssl rand -base64 32)
SESSION_SECRET=$(openssl rand -hex 32)

# Create .env file for Docker Compose
cat > .env << EOF
DB_PASSWORD=$DB_PASSWORD
SESSION_SECRET=$SESSION_SECRET
COMPOSE_PROJECT_NAME=personal-finance-tracker
EOF

print_status "Environment file created"

# Stop any existing containers
print_status "Stopping any existing containers..."
docker-compose down --remove-orphans || true

# Pull latest images
print_status "Pulling latest images..."
docker-compose pull postgres nginx

# Build and start services
print_status "Building and starting services..."
docker-compose up --build -d

# Wait for services to be healthy
print_status "Waiting for services to be healthy..."
for i in {1..30}; do
    if docker-compose ps | grep -q "Up (healthy)"; then
        break
    fi
    echo "Waiting for services to start... ($i/30)"
    sleep 5
done

# Check if all services are running
if docker-compose ps | grep -q "Exit\|Restarting"; then
    print_error "Some services failed to start properly"
    docker-compose logs
    exit 1
fi

print_status "All services started successfully!"

# Run database migrations
print_status "Running database migrations..."
docker-compose exec app npm run db:push

# Display status
print_status "Deployment completed successfully!"
echo ""
echo "================================================="
echo "🐳 Docker Deployment Complete"
echo "================================================="
echo ""
echo "Services Status:"
docker-compose ps
echo ""
echo "Application URL: http://localhost"
echo "Database: PostgreSQL (personal_finance_db)"
echo "Container Management: Docker Compose"
echo ""
echo "Management Commands:"
echo "  docker-compose logs app         # View app logs"
echo "  docker-compose logs postgres    # View database logs"
echo "  docker-compose restart app      # Restart app"
echo "  docker-compose down             # Stop all services"
echo "  docker-compose up -d            # Start all services"
echo ""
echo "Health Check:"
echo "  curl http://localhost/api/health"
echo ""
echo "Environment file: .env"
echo "Keep this file secure!"
echo ""
echo "🚀 Your Personal Finance Tracker is now running in Docker!"