#!/bin/bash

# Pre-deployment checklist for Personal Finance Tracker

echo "================================================="
echo "Pre-deployment Checklist"
echo "================================================="

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

check_pass() { echo -e "${GREEN}✓${NC} $1"; }
check_fail() { echo -e "${RED}✗${NC} $1"; }
check_warn() { echo -e "${YELLOW}⚠${NC} $1"; }

ERRORS=0

# Check Node.js version
echo "Checking Node.js version..."
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    check_pass "Node.js installed: $NODE_VERSION"
else
    check_fail "Node.js not found"
    ERRORS=$((ERRORS + 1))
fi

# Check npm
echo "Checking npm..."
if command -v npm &> /dev/null; then
    NPM_VERSION=$(npm --version)
    check_pass "npm installed: $NPM_VERSION"
else
    check_fail "npm not found"
    ERRORS=$((ERRORS + 1))
fi

# Check required files
echo "Checking required files..."
REQUIRED_FILES=(
    "package.json"
    "server/index.ts"
    "client/src/App.tsx"
    "shared/schema.ts"
    "drizzle.config.ts"
    "vite.config.ts"
    "deploy-vps.sh"
)

for file in "${REQUIRED_FILES[@]}"; do
    if [ -f "$file" ]; then
        check_pass "$file exists"
    else
        check_fail "$file missing"
        ERRORS=$((ERRORS + 1))
    fi
done

# Check if dependencies are installed
echo "Checking dependencies..."
if [ -d "node_modules" ]; then
    check_pass "Dependencies installed"
else
    check_warn "Dependencies not installed - run 'npm install'"
fi

# Check if build works
echo "Testing build process..."
if npm run build &> /dev/null; then
    check_pass "Build successful"
else
    check_fail "Build failed - check your code"
    ERRORS=$((ERRORS + 1))
fi

# Check TypeScript compilation
echo "Checking TypeScript..."
if npm run check &> /dev/null; then
    check_pass "TypeScript compilation successful"
else
    check_warn "TypeScript compilation has issues"
fi

# Check environment variables in production
echo "Checking environment setup..."
if [ -f ".env" ]; then
    check_warn ".env file exists - ensure it's not committed to git"
else
    check_pass "No .env file found (will be created during deployment)"
fi

# Check git status
echo "Checking git status..."
if git status &> /dev/null; then
    if [[ $(git status --porcelain) ]]; then
        check_warn "Uncommitted changes detected"
    else
        check_pass "Git working directory clean"
    fi
else
    check_warn "Not a git repository"
fi

# Summary
echo ""
echo "================================================="
if [ $ERRORS -eq 0 ]; then
    echo -e "${GREEN}✓ Pre-deployment check passed!${NC}"
    echo "You're ready to deploy with ./deploy-vps.sh"
else
    echo -e "${RED}✗ Pre-deployment check failed with $ERRORS errors${NC}"
    echo "Please fix the issues above before deploying"
fi
echo "================================================="

exit $ERRORS