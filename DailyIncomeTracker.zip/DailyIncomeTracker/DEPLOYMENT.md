# Personal Finance Tracker - VPS Deployment Guide

## Quick Start (One-Click Deployment)

### Prerequisites
- Ubuntu 20.04+ VPS with at least 2GB RAM
- Non-root user with sudo privileges
- SSH access to your server

### Deployment Steps

1. **Connect to your VPS**
   ```bash
   ssh username@your-server-ip
   ```

2. **Upload project files**
   ```bash
   # Option 1: Using Git (recommended)
   git clone https://github.com/yourusername/personal-finance-tracker.git
   cd personal-finance-tracker
   
   # Option 2: Upload via SCP from local machine
   scp -r ./personal-finance-tracker username@your-server-ip:~/
   ssh username@your-server-ip
   cd personal-finance-tracker
   ```

3. **Run the deployment script**
   ```bash
   chmod +x deploy-vps.sh
   ./deploy-vps.sh
   ```

4. **Access your application**
   - Open your browser and navigate to: `http://YOUR_SERVER_IP`
   - The application will be running on port 80 (HTTP)

### Post-Deployment Setup

#### Setup SSL Certificate (Optional but Recommended)
```bash
# After pointing your domain to the server IP
./manage.sh ssl yourdomain.com
```

#### Create Regular Backups
```bash
# Create a backup
./manage.sh backup

# Setup automated daily backups (optional)
echo "0 2 * * * cd /var/www/personal-finance-tracker && ./manage.sh backup" | crontab -
```

## Management Commands

The deployment creates a `manage.sh` script for easy application management:

```bash
# Check application status
./manage.sh status

# View application logs
./manage.sh logs

# Restart application
./manage.sh restart

# Create database backup
./manage.sh backup

# Restore from backup
./manage.sh restore /path/to/backup.sql

# Update application (safe update with backup)
./manage.sh update

# Setup SSL certificate
./manage.sh ssl yourdomain.com
```

## What Gets Installed

### System Components
- **Node.js 20** - Runtime environment
- **PostgreSQL** - Database server
- **Nginx** - Web server and reverse proxy
- **PM2** - Process manager for Node.js
- **Certbot** - SSL certificate management
- **UFW** - Firewall configuration

### Application Structure
```
/var/www/personal-finance-tracker/
├── dist/                    # Built application
├── client/                  # Frontend source
├── server/                  # Backend source
├── shared/                  # Shared schemas
├── .env                     # Environment variables
├── manage.sh               # Management script
├── verify-deployment.sh    # Verification script
├── ecosystem.config.cjs    # PM2 configuration
└── package.json           # Dependencies
```

### Database
- **Database Name**: `personal_finance_db`
- **Username**: `finance_user`
- **Password**: Auto-generated (stored in `.env`)

### Logs
- **Application Logs**: `/var/log/personal-finance-tracker/`
- **Nginx Logs**: `/var/log/nginx/`
- **PostgreSQL Logs**: `/var/log/postgresql/`

## Security Features

### Firewall Configuration
- SSH (Port 22) - Enabled
- HTTP (Port 80) - Enabled
- HTTPS (Port 443) - Enabled
- All other ports - Blocked

### Web Security Headers
- X-Frame-Options: DENY
- X-Content-Type-Options: nosniff
- X-XSS-Protection: 1; mode=block
- Referrer-Policy: strict-origin-when-cross-origin
- Content-Security-Policy: Configured for application security

### Database Security
- Dedicated database user with limited privileges
- Strong auto-generated passwords
- Local connections only

## Troubleshooting

### Application Not Starting
```bash
# Check application status
./manage.sh status

# View detailed logs
./manage.sh logs

# Check system resources
free -h
df -h
```

### Database Connection Issues
```bash
# Test database connection
sudo -u postgres psql -c "SELECT 1;"

# Check PostgreSQL service
sudo systemctl status postgresql
```

### Web Server Issues
```bash
# Test Nginx configuration
sudo nginx -t

# Check Nginx status
sudo systemctl status nginx

# View Nginx logs
sudo tail -f /var/log/nginx/error.log
```

### SSL Certificate Issues
```bash
# Check certificate status
sudo certbot certificates

# Renew certificates
sudo certbot renew --dry-run
```

## Updating the Application

### Safe Update Process
The `manage.sh update` command performs a safe update:
1. Creates a database backup
2. Stops the application
3. Pulls latest code changes
4. Installs dependencies
5. Updates database schema
6. Builds the application
7. Restarts the application

```bash
./manage.sh update
```

### Manual Update
If you need more control over the update process:
```bash
# Stop application
pm2 stop personal-finance-tracker

# Backup database
./manage.sh backup

# Update code
git pull

# Install dependencies
npm install

# Update database schema
npm run db:push

# Build application
npm run build

# Start application
pm2 start personal-finance-tracker
```

## Performance Optimization

### For Small VPS (1GB RAM)
```bash
# Adjust PM2 configuration for lower memory usage
nano ecosystem.config.cjs

# Reduce max_memory_restart to 512M
# Reduce node_args max-old-space-size to 512
```

### For Better Performance
```bash
# Enable PM2 cluster mode (for multi-core systems)
nano ecosystem.config.cjs

# Change instances to 'max' or specific number
# Set exec_mode to 'cluster'
```

## Monitoring

### Application Monitoring
```bash
# Real-time application logs
./manage.sh logs

# System resource usage
htop

# Database performance
sudo -u postgres psql -c "SELECT * FROM pg_stat_activity;"
```

### Setup Monitoring Alerts (Optional)
```bash
# Install monitoring tools
sudo apt install htop iotop

# Setup log rotation
sudo nano /etc/logrotate.d/personal-finance-tracker
```

## Backup Strategy

### Automated Backups
```bash
# Create backup script
crontab -e

# Add daily backup at 2 AM
0 2 * * * cd /var/www/personal-finance-tracker && ./manage.sh backup

# Add weekly cleanup (keep last 30 days)
0 3 * * 0 find /var/backups/personal-finance-tracker -name "backup_*.sql" -mtime +30 -delete
```

### Manual Backups
```bash
# Create backup
./manage.sh backup

# Copy backup to remote location
scp /var/backups/personal-finance-tracker/backup_*.sql user@backup-server:/backups/
```

## Support

If you encounter any issues:
1. Check the troubleshooting section above
2. Review application logs: `./manage.sh logs`
3. Verify deployment: `./verify-deployment.sh`
4. Check system resources: `free -h` and `df -h`

## Security Best Practices

1. **Keep system updated**: `sudo apt update && sudo apt upgrade`
2. **Use strong passwords**: Generated automatically by script
3. **Enable firewall**: Configured automatically
4. **Use SSL certificates**: `./manage.sh ssl yourdomain.com`
5. **Regular backups**: `./manage.sh backup`
6. **Monitor logs**: `./manage.sh logs`
7. **Limit SSH access**: Configure SSH key authentication
8. **Keep application updated**: `./manage.sh update`