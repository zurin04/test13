#!/bin/bash

# Personal Finance Tracker - Complete One-Click Deployment
# Handles everything: system setup, database, application, web server, SSL

set -e

echo "================================================="
echo "Personal Finance Tracker - Complete Deployment"
echo "================================================="

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() { echo -e "${GREEN}[INFO]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARN]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }
print_step() { echo -e "${BLUE}[STEP]${NC} $1"; }

# Function to handle errors and continue
handle_error() {
    local exit_code=$?
    local line_number=$1
    if [ $exit_code -ne 0 ]; then
        print_warning "Error on line $line_number (exit code: $exit_code), attempting to continue..."
        return 0
    fi
}

# Trap errors but continue execution
trap 'handle_error $LINENO' ERR

# Check prerequisites
print_step "Checking prerequisites..."
if [[ $EUID -eq 0 ]]; then
    print_error "Do not run as root. Use a regular user with sudo privileges."
    exit 1
fi

if ! command -v sudo >/dev/null; then
    print_error "sudo is required but not installed."
    exit 1
fi

# Get domain for SSL (optional)
print_step "Checking for domain configuration..."
DOMAIN=""
if [ "$1" != "" ]; then
    DOMAIN="$1"
    print_status "Domain provided: $DOMAIN"
else
    print_warning "No domain provided. SSL will be skipped. Usage: $0 [domain.com]"
fi

# Update system
print_step "Updating system packages..."
sudo apt update -y || print_warning "System update failed, continuing..."

# Install system dependencies
print_step "Installing system dependencies..."
sudo DEBIAN_FRONTEND=noninteractive apt install -y \
    curl wget gnupg postgresql postgresql-contrib nginx \
    certbot python3-certbot-nginx python3 build-essential \
    git ufw htop || print_warning "Some packages failed to install, continuing..."

# Install Node.js 20
print_step "Installing Node.js 20..."
if ! command -v node &>/dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - || print_warning "Node.js setup failed"
    sudo apt install -y nodejs || print_warning "Node.js install failed"
else
    print_status "Node.js already installed: $(node --version)"
fi

# Install PM2 and TSX
print_step "Installing PM2 and TSX..."
sudo npm install -g pm2 tsx 2>/dev/null || print_warning "PM2/TSX install failed, may already be installed"

# Start and enable services
print_step "Starting system services..."
sudo systemctl enable postgresql nginx || print_warning "Service enable failed"
sudo systemctl start postgresql || print_warning "PostgreSQL start failed"
sudo systemctl start nginx || print_warning "Nginx start failed"

# Setup application directory
APP_DIR="/var/www/personal-finance-tracker"
print_step "Setting up application directory..."
sudo mkdir -p $APP_DIR || print_warning "Directory creation failed"
sudo chown $USER:$USER $APP_DIR || print_warning "Directory ownership failed"

# Copy application files
print_step "Copying application files..."
if [ -d ".git" ]; then
    # If this is a git repo, clone fresh
    git clone . $APP_DIR/ 2>/dev/null || cp -r . $APP_DIR/
else
    cp -r . $APP_DIR/
fi
cd $APP_DIR

# Generate secure credentials
print_step "Generating secure credentials..."
DB_PASSWORD=$(openssl rand -base64 32 2>/dev/null || echo "change_me_$(date +%s)")
SESSION_SECRET=$(openssl rand -hex 32 2>/dev/null || echo "change_me_session_$(date +%s)")

# Setup PostgreSQL database
print_step "Setting up PostgreSQL database..."
sudo -u postgres psql << EOF || print_warning "Database setup may have failed"
DROP DATABASE IF EXISTS personal_finance_db;
DROP USER IF EXISTS finance_user;
CREATE USER finance_user WITH PASSWORD '$DB_PASSWORD' SUPERUSER;
CREATE DATABASE personal_finance_db OWNER finance_user;
GRANT ALL PRIVILEGES ON DATABASE personal_finance_db TO finance_user;
\q
EOF

# Create environment file
print_step "Creating environment configuration..."
cat > .env << ENV
DATABASE_URL=postgresql://finance_user:$DB_PASSWORD@localhost:5432/personal_finance_db
SESSION_SECRET=$SESSION_SECRET
NODE_ENV=production
PORT=5000
PGHOST=localhost
PGPORT=5432
PGUSER=finance_user
PGPASSWORD=$DB_PASSWORD
PGDATABASE=personal_finance_db
ENV

# Install dependencies
print_step "Installing application dependencies..."
npm install || {
    print_warning "npm install failed, trying with --legacy-peer-deps"
    npm install --legacy-peer-deps || print_warning "Dependency install failed"
}

# Setup database schema
print_step "Setting up database schema..."
export $(grep -v '^#' .env | xargs)

# Test database connection
print_step "Testing database connection..."
if ! PGPASSWORD="$DB_PASSWORD" psql -h localhost -U finance_user -d personal_finance_db -c "SELECT 1;" >/dev/null 2>&1; then
    print_warning "Database connection failed, attempting to fix..."
    
    # Try to restart PostgreSQL
    sudo systemctl restart postgresql
    sleep 5
    
    # Try to recreate user and database
    sudo -u postgres psql << EOF || print_warning "Database recreation failed"
DROP DATABASE IF EXISTS personal_finance_db;
DROP USER IF EXISTS finance_user;
CREATE USER finance_user WITH PASSWORD '$DB_PASSWORD' SUPERUSER;
CREATE DATABASE personal_finance_db OWNER finance_user;
GRANT ALL PRIVILEGES ON DATABASE personal_finance_db TO finance_user;
\q
EOF
fi

# Push database schema
print_step "Pushing database schema..."
npm run db:push || {
    print_warning "Schema push failed, trying alternative method..."
    # Try with different URL format
    export DATABASE_URL="postgresql://finance_user:$(echo $DB_PASSWORD | sed 's/@/%40/g')@localhost:5432/personal_finance_db"
    npm run db:push || print_warning "Schema push failed, may need manual intervention"
}

# Build application
print_step "Building application..."
export NODE_OPTIONS="--max-old-space-size=4096"
timeout 600 npm run build || {
    print_warning "Build failed or timed out, trying with less memory..."
    export NODE_OPTIONS="--max-old-space-size=2048"
    timeout 300 npm run build || {
        print_warning "Build failed, trying without memory limit..."
        unset NODE_OPTIONS
        npm run build || print_warning "Build failed completely"
    }
}

# Create PM2 ecosystem configuration
print_step "Creating PM2 configuration..."
cat > ecosystem.config.cjs << 'EOF'
module.exports = {
  apps: [{
    name: 'personal-finance-tracker',
    script: './dist/index.js',
    instances: 1,
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 5000
    },
    error_file: '/var/log/personal-finance-tracker/error.log',
    out_file: '/var/log/personal-finance-tracker/out.log',
    log_file: '/var/log/personal-finance-tracker/combined.log',
    time: true,
    max_memory_restart: '1G',
    node_args: '--max-old-space-size=1024',
    restart_delay: 4000,
    max_restarts: 10,
    min_uptime: '10s'
  }]
};
EOF

# Setup logs directory
sudo mkdir -p /var/log/personal-finance-tracker || print_warning "Log directory creation failed"
sudo chown $USER:$USER /var/log/personal-finance-tracker || print_warning "Log directory ownership failed"

# Configure Nginx
print_step "Configuring Nginx..."
if [ "$DOMAIN" != "" ]; then
    SERVER_NAME="$DOMAIN"
else
    SERVER_NAME="_"
fi

sudo tee /etc/nginx/sites-available/personal-finance-tracker > /dev/null << EOF
server {
    listen 80;
    server_name $SERVER_NAME;
    client_max_body_size 50M;
    
    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";
    add_header Referrer-Policy "strict-origin-when-cross-origin";
    
    # Rate limiting
    limit_req_zone \$binary_remote_addr zone=api:10m rate=10r/s;
    limit_req_zone \$binary_remote_addr zone=login:10m rate=5r/m;
    
    # Health check endpoint
    location /api/health {
        proxy_pass http://localhost:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # API endpoints with rate limiting
    location /api/auth/login {
        limit_req zone=login burst=5 nodelay;
        proxy_pass http://localhost:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    location /api/ {
        limit_req zone=api burst=20 nodelay;
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 86400;
    }
    
    # Main application
    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 86400;
    }
}
EOF

# Enable site and test configuration
sudo ln -sf /etc/nginx/sites-available/personal-finance-tracker /etc/nginx/sites-enabled/ || print_warning "Nginx site link failed"
sudo rm -f /etc/nginx/sites-enabled/default || print_warning "Default site removal failed"

if sudo nginx -t; then
    print_status "Nginx configuration valid"
    sudo systemctl reload nginx || print_warning "Nginx reload failed"
else
    print_warning "Nginx configuration invalid, but continuing..."
fi

# Stop any existing PM2 processes
print_step "Stopping existing PM2 processes..."
pm2 delete all 2>/dev/null || print_warning "No existing PM2 processes to stop"

# Start application with PM2
print_step "Starting application with PM2..."
pm2 start ecosystem.config.cjs || {
    print_warning "PM2 start failed, trying alternative..."
    # Try starting directly
    cd $APP_DIR
    pm2 start dist/index.js --name personal-finance-tracker || print_warning "Direct PM2 start failed"
}

pm2 save || print_warning "PM2 save failed"

# Setup PM2 startup
print_step "Configuring PM2 auto-startup..."
sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u $USER --hp $HOME || print_warning "PM2 startup setup failed"

# Configure firewall
print_step "Configuring firewall..."
sudo ufw --force enable || print_warning "UFW enable failed"
sudo ufw allow 22,80,443/tcp || print_warning "UFW rules failed"

# Setup SSL if domain provided
if [ "$DOMAIN" != "" ]; then
    print_step "Setting up SSL certificate for $DOMAIN..."
    
    # Wait for DNS to propagate
    print_status "Waiting 30 seconds for DNS to propagate..."
    sleep 30
    
    # Get SSL certificate
    sudo certbot --nginx -d $DOMAIN --non-interactive --agree-tos --email admin@$DOMAIN || {
        print_warning "SSL setup failed. You can try manually later with:"
        print_warning "sudo certbot --nginx -d $DOMAIN"
    }
fi

# Create management script
print_step "Creating management script..."
cat > manage.sh << 'SCRIPT'
#!/bin/bash

# Load environment variables
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

BACKUP_DIR="/var/backups/personal-finance-tracker"

case $1 in
    status)
        echo "=== Application Status ==="
        pm2 status
        echo ""
        echo "=== System Resources ==="
        free -h
        df -h
        echo ""
        echo "=== Service Status ==="
        systemctl is-active nginx postgresql
        ;;
    logs)
        pm2 logs personal-finance-tracker
        ;;
    restart)
        pm2 restart personal-finance-tracker
        ;;
    backup)
        mkdir -p $BACKUP_DIR
        BACKUP_FILE="$BACKUP_DIR/backup_$(date +%Y%m%d_%H%M%S).sql"
        if PGPASSWORD="$PGPASSWORD" pg_dump -h localhost -U finance_user personal_finance_db > $BACKUP_FILE; then
            echo "✓ Backup saved to: $BACKUP_FILE"
            ls -t $BACKUP_DIR/backup_*.sql | tail -n +8 | xargs -r rm
        else
            echo "✗ Backup failed!"
        fi
        ;;
    ssl)
        if [ -z "$2" ]; then
            echo "Usage: $0 ssl yourdomain.com"
            exit 1
        fi
        sudo certbot --nginx -d $2 --non-interactive --agree-tos --email admin@$2
        ;;
    *)
        echo "Personal Finance Tracker Management"
        echo "Usage: $0 {status|logs|restart|backup|ssl}"
        ;;
esac
SCRIPT

chmod +x manage.sh

# Verify deployment
print_step "Verifying deployment..."
sleep 10

# Check if application is running
if pm2 list | grep -q "personal-finance-tracker.*online"; then
    print_status "✓ Application is running"
else
    print_warning "✗ Application may not be running properly"
    pm2 restart personal-finance-tracker || print_warning "Restart failed"
fi

# Check web server response
if curl -f -s http://localhost >/dev/null 2>&1; then
    print_status "✓ Web server responding"
else
    print_warning "✗ Web server not responding, checking..."
    sudo systemctl restart nginx
    sleep 5
fi

# Final status check
print_step "Final status check..."
./manage.sh status

# Display completion message
echo ""
echo "================================================="
echo "🎉 Deployment Complete!"
echo "================================================="
echo ""

# Get public IP
PUBLIC_IP=$(curl -s ifconfig.me 2>/dev/null || curl -s ipinfo.io/ip 2>/dev/null || echo "YOUR_SERVER_IP")

if [ "$DOMAIN" != "" ]; then
    echo "🌐 Application URL: https://$DOMAIN"
    echo "🔒 SSL Certificate: Configured"
else
    echo "🌐 Application URL: http://$PUBLIC_IP"
    echo "⚠️  SSL: Not configured (no domain provided)"
fi

echo ""
echo "📊 Database: PostgreSQL (personal_finance_db)"
echo "⚙️  Process Manager: PM2"
echo "🔧 Web Server: Nginx"
echo ""
echo "🛠️  Management Commands:"
echo "   ./manage.sh status   - Check status"
echo "   ./manage.sh logs     - View logs"
echo "   ./manage.sh restart  - Restart app"
echo "   ./manage.sh backup   - Create backup"
echo "   ./manage.sh ssl      - Setup SSL"
echo ""
echo "📁 Application Directory: $APP_DIR"
echo "📄 Environment File: .env"
echo "📋 Logs: /var/log/personal-finance-tracker/"
echo ""

if [ "$DOMAIN" == "" ]; then
    echo "💡 To setup SSL later:"
    echo "   ./manage.sh ssl yourdomain.com"
    echo ""
fi

echo "🚀 Your Personal Finance Tracker is now live!"
echo "================================================="